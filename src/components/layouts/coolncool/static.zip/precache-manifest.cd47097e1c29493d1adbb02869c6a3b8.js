self.__precacheManifest = [
  {
    "revision": "bd1ab6ce571a70c1fd25",
    "url": "/static/css/main.3b9f8e54.chunk.css"
  },
  {
    "revision": "bd1ab6ce571a70c1fd25",
    "url": "/static/js/main.bd1ab6ce.chunk.js"
  },
  {
    "revision": "1b922744246c39b6bc43",
    "url": "/static/js/runtime~main.1b922744.js"
  },
  {
    "revision": "2139e6d63726d85fc625",
    "url": "/static/css/2.73136921.chunk.css"
  },
  {
    "revision": "2139e6d63726d85fc625",
    "url": "/static/js/2.2139e6d6.chunk.js"
  },
  {
    "revision": "efe4e1811b0be806e1490f2347164852",
    "url": "/static/media/profile.efe4e181.png"
  },
  {
    "revision": "d881b48190ee1ae8ae77597be8186df0",
    "url": "/static/media/herbal.d881b481.gif"
  },
  {
    "revision": "ad139c218c2c783d60631586e240e2c8",
    "url": "/index.html"
  }
];